<!DOCTYPE html>
<html class="dark">
  <head>
    <link href="output.css" rel="stylesheet">
  </head>
  <body class="bg-white dark:bg-gray-900 text-black dark:text-white">
    <h1 class="text-3xl">Modo Oscuro</h1>
    <button onclick="toggleDarkMode()">Alternar Modo Oscuro</button>
    <script>
      function toggleDarkMode() {
        document.documentElement.classList.toggle("dark");
      }
    </script>
  </body>
</html>