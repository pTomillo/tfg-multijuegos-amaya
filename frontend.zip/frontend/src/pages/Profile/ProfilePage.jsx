export default function ProfilePage() {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold">
        Bienvenido a los Profile de Multijuegos Amaya 🎮
      </h1>
    </div>
  );
}
