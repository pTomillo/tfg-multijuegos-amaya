export default function RegisterPage() {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold">
        Bienvenido a Register Multijuegos Amaya 🎮
      </h1>
    </div>
  );
}
